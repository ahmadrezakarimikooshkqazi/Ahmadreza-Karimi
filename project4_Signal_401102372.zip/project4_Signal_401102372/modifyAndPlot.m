function modifyAndPlot(refSignal, refName, A1, G1, F1, G_ref, F_ref, w, fs, x1, outputFileName)
    % Modify the LPC encoded coefficients of the first signal based on the reference signal
    A_mod = A1; % Use the same LPC coefficients
    G_mod = G1 .* (G_ref ./ G1); % Adjust the power to match the reference signal
    F_mod = F1 .* (F_ref ./ F1); % Adjust the pitch to match the reference signal

    % LPC decode the modified signal
    GFE_mod = [G_mod; F_mod];
    x_mod = lpcDecode(A_mod, GFE_mod, w);

    % Normalize the modified signal
    x_mod = 0.9 * x_mod / max(abs(x_mod));

    % Play the modified signal
    sound(x_mod, fs);
    pause(length(x_mod)/fs + 1);

    % Plot original, reference, and modified signals
    figure;
    subplot(3,1,1);
    plot(x1);
    title('Original Signal (Person)');

    subplot(3,1,2);
    plot(refSignal);
    title(['Reference Signal (' refName ')']);

    subplot(3,1,3);
    plot(x_mod);
    title('Modified Signal (Person with Reference Characteristics)');

    % Save the modified signal to a file
    audiowrite(outputFileName, x_mod, fs);
end
