%قسمت اول
%کاربر یک فایل صوتی را از حافظه انخاب میکند
[filename, pathname] = uigetfile('*.wav', 'Select an audio file'); 
audioFile = fullfile(pathname, filename); 
filterOrders = [6, 12, 18, 24]; 
fs_target = 8000; 
compressionRatios = [15, 8.6, 4.6]; 

% بارگذاری صدا
[x, fs] = audioread(audioFile); 
%نرمال کردن
x = mean(x, 2); 
x = 0.9*x/max(abs(x)); 
x = resample(x, fs_target, fs); %نمونه گیری
fs = fs_target;
w = hann(floor(0.03*fs), 'periodic'); 
fprintf('Processing %s...\n', audioFile);

% پخش صدای اصلی
sound(x, fs);
pause(length(x)/fs + 1);

for p = filterOrders
    % انکود
    [A, G] = lpcEncode(x, p, w);
    
    % دیکود
    xhat = lpcDecode(A, G, w);
    
    % برابر کردن طول
    len = min(length(x), length(xhat));
    x_orig = x(1:len);
    xhat = xhat(1:len);
    
    % محاسبه MSE
    mse = mean((x_orig - xhat).^2);
    
    % محاسبه نسبت تراکم
    nSig = length(x_orig);
    sz = size(A);
    nLPC = sz(1)*sz(2) + length(G);
    compressionRatio = nSig / nLPC;
    
    % نتیجه
    fprintf('Filter order: %d\n', p);
    fprintf('Mean Squared Error: %.6f\n', mse);
    fprintf('Compression Ratio: %.2f\n\n', compressionRatio);
    
    %رسم
    figure;
    subplot(2,1,1);
    plot(x_orig);
    title('Original Signal');
    subplot(2,1,2);
    plot(xhat);
    title(['Reconstructed Signal (Filter order: ' num2str(p) ')']);
    sound(xhat, fs);
    pause(length(xhat)/fs + 1);
    
    % ذخیره
    outputFileName = sprintf('output/lpc_breathy_order_%d.wav', p);
    audiowrite(outputFileName, xhat, fs); % Using audiowrite instead of wavwrite
    
    % نویز و تشخیص گام برای هر نسبت تراکم
    for cr = compressionRatios
        p_cr = round(p / (compressionRatio / cr));
        
        % انکود
        [A_cr, G_cr] = lpcEncode(x, p_cr, w);
        
        % LPC Decode with new order
        xhat_cr = lpcDecode(A_cr, G_cr, w);
        
        %برابر کردن طول
        len_cr = min(length(x), length(xhat_cr));
        x_orig_cr = x(1:len_cr);
        xhat_cr = xhat_cr(1:len_cr);
        
        % محاسبه MSE
        mse_cr = mean((x_orig_cr - xhat_cr).^2);
        
        %محاسبه نسبت تراکم
        nLPC_cr = sz(1)*sz(2) + length(G_cr);
        compressionRatio_cr = nSig / nLPC_cr;
        
        % نمایش نتایج
        fprintf('Filter order: %d, Compression Ratio: %.2f\n', p_cr, compressionRatio_cr);
        fprintf('Mean Squared Error: %.6f\n', mse_cr);
        
        % رسم
        figure;
        subplot(2,1,1);
        plot(x_orig_cr);
        title('Original Signal');
        subplot(2,1,2);
        plot(xhat_cr);
        title(['Reconstructed Signal (Filter order: ' num2str(p_cr) ', Compression Ratio: ' num2str(cr) ')']);
        sound(xhat_cr, fs);
        pause(length(xhat_cr)/fs + 1);
        
        % ذخیره
        outputFileName_cr = sprintf('output/lpc_breathy_order_%d_cr_%.1f.wav', p, cr);
        audiowrite(outputFileName_cr, xhat_cr, fs);
    end
end
%%
%قسمت دوم
%تابع تعریف شده درون کد در پایین ضمیمه شده است
% انتخاب چهار فایل صوتی
%ابتدا صدای فرد
[filename1, pathname1] = uigetfile('*.wav', 'Select the first audio file (Person)');
audioFile1 = fullfile(pathname1, filename1);
%صدای اول
[filename2, pathname2] = uigetfile('*.wav', 'Select the second audio file (Reference 1)');
audioFile2 = fullfile(pathname2, filename2);
%صدای دوم
[filename3, pathname3] = uigetfile('*.wav', 'Select the third audio file (Reference 2)');
audioFile3 = fullfile(pathname3, filename3);
%صدای سوم
[filename4, pathname4] = uigetfile('*.wav', 'Select the fourth audio file (Reference 3)');
audioFile4 = fullfile(pathname4, filename4);

fs_target = 8000; 
filterOrder = 24; 
windowLength = 0.03;
np = 5; 

% ذخیره فایل های صوتی
[x1, fs1] = audioread(audioFile1); 
[x2, fs2] = audioread(audioFile2); 
[x3, fs3] = audioread(audioFile3); 
[x4, fs4] = audioread(audioFile4); 

% نرمال کردن
x1 = mean(x1, 2); 
x1 = 0.9 * x1 / max(abs(x1));
x2 = mean(x2, 2); 
x2 = 0.9 * x2 / max(abs(x2));
x3 = mean(x3, 2); 
x3 = 0.9 * x3 / max(abs(x3));
x4 = mean(x4, 2); 
x4 = 0.9 * x4 / max(abs(x4));

% نمونه گیری
x1 = resample(x1, fs_target, fs1);
x2 = resample(x2, fs_target, fs2);
x3 = resample(x3, fs_target, fs3);
x4 = resample(x4, fs_target, fs4);
fs = fs_target;

% تطابق طول سیگنال ها
n = min([length(x1), length(x2), length(x3), length(x4)]);
x1 = x1(1:n);
x2 = x2(1:n);
x3 = x3(1:n);
x4 = x4(1:n);

w = hann(floor(windowLength * fs), 'periodic');

% انکود کردن
[A1, G1, E1] = lpcEncode(x1, filterOrder, w);
[A2, G2, E2] = lpcEncode(x2, filterOrder, w);
[A3, G3, E3] = lpcEncode(x3, filterOrder, w);
[A4, G4, E4] = lpcEncode(x4, filterOrder, w);

% تشخیص پیچ
[F1, ~] = lpcFindPitch(x1, w, np);
[F2, ~] = lpcFindPitch(x2, w, np);
[F3, ~] = lpcFindPitch(x3, w, np);
[F4, ~] = lpcFindPitch(x4, w, np);

%رسم
modifyAndPlot(x2, 'Reference 1', A1, G1, F1, G2, F2, w, fs, x1, 'output/modified_signal_ref1.wav');
modifyAndPlot(x3, 'Reference 2', A1, G1, F1, G3, F3, w, fs, x1, 'output/modified_signal_ref2.wav');
modifyAndPlot(x4, 'Reference 3', A1, G1, F1, G4, F4, w, fs, x1, 'output/modified_signal_ref3.wav');
%%
%تابع قسمت دوم
function modifyAndPlot(refSignal, refName, A1, G1, F1, G_ref, F_ref, w, fs, x1, outputFileName)
    A_mod = A1; 
    G_mod = G1 .* (G_ref ./ G1); %توان مثل سیگنال مرجع بشه
    F_mod = F1 .* (F_ref ./ F1); % پیچ مثل سیگنال مرجع بشه

    % دیکود
    GFE_mod = [G_mod; F_mod];
    x_mod = lpcDecode(A_mod, GFE_mod, w);
    x_mod = 0.9 * x_mod / max(abs(x_mod));
    sound(x_mod, fs);
    pause(length(x_mod)/fs + 1);

    % رسم
    figure;
    subplot(3,1,1);
    plot(x1);
    title('Original Signal (Person)');

    subplot(3,1,2);
    plot(refSignal);
    title(['Reference Signal (' refName ')']);

    subplot(3,1,3);
    plot(x_mod);
    title('Modified Signal (Person with Reference Characteristics)');

    % ذخیره بکن
    audiowrite(outputFileName, x_mod, fs);
end

